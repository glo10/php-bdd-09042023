<?php

// Traitement de l'inscription depuis une soumission du formulaire d'inscription côté front
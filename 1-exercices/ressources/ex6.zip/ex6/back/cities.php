<?php
// TODO Récupérez les villes depuis une requête ajax avec du JS qui a été fournie
/**
 * $cities est un JSON après traitement avec PHP grâce au pays envoyé en ajax côté JS
 * Vous devez récupérer le pays à partir de la requête envoyé depuis le client
 * et à partir de celui-ci obtenir les villes associées à récupérer depuis data/countries_and_cities.json
 * Aides avec des fonctions utilitaires
 * @see https://www.php.net/manual/fr/function.file-get-contents
 * @see https://www.php.net/manual/fr/function.json-encode
 * @see https://www.php.net/manual/fr/function.json-decode.php
 * @see https://www.php.net/manual/fr/wrappers.php.php
 * @var $cities
 */
// echo json_encode($cities);
